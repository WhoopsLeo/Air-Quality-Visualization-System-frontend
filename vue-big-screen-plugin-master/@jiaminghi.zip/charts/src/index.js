import Charts from './class/charts.class'

export { changeDefaultConfig } from './config'

export default Charts