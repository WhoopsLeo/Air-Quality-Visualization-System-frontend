import FlylineChartEnhanced from './src/main.vue'

export default function (Vue) {
  Vue.component(FlylineChartEnhanced.name, FlylineChartEnhanced)
}
