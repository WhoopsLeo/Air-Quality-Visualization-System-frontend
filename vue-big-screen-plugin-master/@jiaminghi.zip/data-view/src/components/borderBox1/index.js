import BorderBox1 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox1.name, BorderBox1)
}
