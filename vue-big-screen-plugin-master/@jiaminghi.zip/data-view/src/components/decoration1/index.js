import Decoration1 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration1.name, Decoration1)
}
