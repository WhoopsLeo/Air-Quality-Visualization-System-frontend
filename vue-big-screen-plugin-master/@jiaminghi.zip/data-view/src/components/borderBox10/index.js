import BorderBox10 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox10.name, BorderBox10)
}
