import ScrollBoard from './src/main.vue'

export default function (Vue) {
  Vue.component(ScrollBoard.name, ScrollBoard)
}
