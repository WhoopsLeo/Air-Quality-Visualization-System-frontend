import Decoration3 from './src/main.vue'

export default function (Vue) {
  Vue.component(Decoration3.name, Decoration3)
}
