import ActiveRingChart from './src/main.vue'

export default function (Vue) {
  Vue.component(ActiveRingChart.name, ActiveRingChart)
}
