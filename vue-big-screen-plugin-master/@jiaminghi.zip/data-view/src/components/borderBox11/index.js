import BorderBox11 from './src/main.vue'

export default function (Vue) {
  Vue.component(BorderBox11.name, BorderBox11)
}
