# 0.0.9-alpha (2019-08-28)

### Perfect

- **babel:** Upgrade babel compilation mode.

# 0.0.8-alpha (2019-08-28)

### Perfect

- **babel:** Upgrade babel compilation mode.

# 0.0.7-alpha (2019-08-28)

### Perfect

- **babel:** Upgrade babel compilation mode.

# 0.0.6-alpha (2019-07-08)

### Perfect

- **export:** Optimized export method.

# 0.0.5-alpha (2019-06-06)

### Perfect

- **ES5:** Use babel to transcode to `ES5`.

# 0.0.4-alpha (2019-04-11)

### perfect

 * **note:** Update note

# 0.0.3-alpha (2019-04-03)

### perfect

 * **add:** Add a readme file

# 0.0.2-alpha (2019-04-03)

### Enhance

 * **optmization:** Add a polyline abstraction to a curve algorithm

# 0.0.1-alpha (2019-03-30)

### Enhance

 * **optmization:** Improve the calcUniformPointsByIteration algorithm