# 0.1.1-alpha (2019-08-28)

### Perfect

- **babel:** Upgrade babel compilation mode.

# 0.1.0-alpha (2019-07-07)

### Perfect

- **keywords:** Support color keywords like red, blue, transparent and etc.

# 0.0.6-alpha (2019-06-13)

### Bug Fixes

- **getOpacity:** Fix the exception caused by the decimal in the rgba color (Like 'rgba(123.3333, 111, 111, 0.323)').

# 0.0.5-alpha (2019-06-06)

### Perfect

- **ES5:** Use babel to transcode to `ES5`.

# 0.0.4-alpha (2019-05-15)

### Publish

* **version:** V 0.0.4-alpha.

# 0.0.3-alpha (2019-04-30)

### Bug Fixes

* **getOpacity:** Abnormal calculation due to spaces.

# 0.0.2-alpha (2019-04-08)

### Publish

 * **version:** V 0.0.2-alpha.

# 0.0.1-alpha (2019-04-04)

### Publish

 * **version:** V 0.0.1-alpha.