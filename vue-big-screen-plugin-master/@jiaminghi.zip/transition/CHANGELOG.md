# 1.1.11-alpha (2019-08-29)

### Perfect

- **babel:** Upgrade babel compilation mode.

# 1.1.10-alpha (2019-07-08)

### Perfect

- **core:** Do some optimizations.

# 1.1.9-alpha (2019-06-06)

### Bug Fixes

- **core:** Default export exception.

# 1.1.8-alpha (2019-06-06)

### Perfect

- **ES5:** Use babel to transcode to `ES5`.

# 1.1.7-alpha (2019-06-06)

### Perfect

- **curve:** Optmization curve `easeOutCubic`.

# 1.1.6-alpha (2019-05-23)

### Perfect

- **core:** Add try cacth to enhance compatibility (when the parameter exception causes an error, it returns directly to the "End State").

# 1.1.5-alpha (2019-05-07)

### Bug Fixes

- **core:** Fix an exception caused by a variable name error.

# 1.1.4-alpha (2019-04-28)

### Perfect

- **curve:** Improve the commonly used easing curve.